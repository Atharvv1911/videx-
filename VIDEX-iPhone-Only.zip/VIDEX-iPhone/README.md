# VIDEX — iPhone-only starter

This is a Progressive Web App (PWA) starter. It is not a native App Store app.

## What works
- Recognizes YouTube and Instagram viewing links and explains the official/authorized route.
- Accepts direct MP4/MOV/M4V/WebM file URLs (subject to the file host's permissions and CORS/browser behavior).
- Imports videos selected from the iPhone Photos/Files picker.
- Offers the iOS share sheet where supported.
- Responsive dark interface and service-worker caching.

## Important limitations
- A YouTube/Instagram page URL is not a direct media file. This app does not scrape streams, bypass DRM, private-account controls, or platform restrictions.
- Quality is whatever the authorized source provides. The app does not upscale or re-encode.
- The in-app library is session-based in this starter. Imported video files are not copied into permanent app storage by this simple web version.
- To install as a Home Screen web app, it must be hosted over HTTPS. Opening index.html directly from Files is useful for preview, but does not enable PWA installation/offline caching.

## Publish using only an iPhone (GitHub Pages)
1. In Safari, sign in to GitHub and create a new **public** repository named `videx`.
2. Choose **Add file → Upload files** and upload `index.html`, `manifest.webmanifest`, and `sw.js` from this folder. Commit the upload.
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish. Your site will be at `https://YOUR-USERNAME.github.io/videx/`.
6. Open that URL in Safari on your iPhone, tap Share → Add to Home Screen → Add.

Keep the repository public only if you are comfortable with the app source being public. Do not upload private videos or credentials to the repository.
